<?php
/**
 * Template Name: Knowledge Base
 *
 * Selectable from a dropdown menu on the edit page screen.
 */
define('WP_USE_THEMES', false);
$GLOBALS['ALAcontentType'] = 'Knowledge Base';
include 'page_core.php';
?>