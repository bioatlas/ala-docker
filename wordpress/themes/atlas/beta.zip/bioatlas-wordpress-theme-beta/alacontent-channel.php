<?php
/**
 * Template Name: Channel
 *
 * Selectable from a dropdown menu on the edit page screen.
 */
define('WP_USE_THEMES', false);
$GLOBALS['ALAcontentType'] = 'Channel';
include 'page_core.php';
?>