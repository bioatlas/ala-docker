<?php
/**
 * Template Name: Page
 *
 * Selectable from a dropdown menu on the edit page screen.
 */
define('WP_USE_THEMES', false);
$GLOBALS['ALAcontentType'] = 'Page';
include 'page_core.php';
?>