<?php 
  $GLOBALS['ALAcontentType'] = 'Article';
  include 'page_core.php';
?>

