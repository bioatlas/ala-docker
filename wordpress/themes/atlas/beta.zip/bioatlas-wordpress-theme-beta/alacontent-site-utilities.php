<?php
/**
 * Template Name: Site Utilities
 *
 * Selectable from a dropdown menu on the edit page screen.
 */
define('WP_USE_THEMES', false);
$GLOBALS['ALAcontentType'] = 'Site Utilities';
include 'page_core.php';
?>