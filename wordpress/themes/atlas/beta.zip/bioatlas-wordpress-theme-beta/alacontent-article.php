<?php
/**
 * Template Name: Article
 *
 * Selectable from a dropdown menu on the edit page screen.
 */
define('WP_USE_THEMES', false);
$GLOBALS['ALAcontentType'] = 'Article';
include 'page_core.php';
?>